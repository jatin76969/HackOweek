# Travel Planner - Flowchart Documentation

## 🔄 Main Program Flowchart

```
                    START
                      |
                      ↓
            Initialize Web Page
                      |
                      ↓
         Display Input Form
         (Destination + Days)
                      |
                      ↓
         Wait for User Input
                      |
                      ↓
         User Clicks Calculate
                      |
                      ↓
         ┌─────────────────────┐
         │  Get Destination    │
         │  Get Number of Days │
         └─────────────────────┘
                      |
                      ↓
         ┌─────────────────────┐
         │ Is Destination      │
         │ Selected?           │
         └─────────────────────┘
                /        \
              NO          YES
              /            \
             ↓              ↓
    Show Error:      ┌─────────────────┐
    "Select          │ Is Days between │
    Destination"     │ 1 and 30?       │
             |       └─────────────────┘
             |            /        \
             |          NO          YES
             |          /            \
             |         ↓              ↓
             |    Show Error:    Retrieve
             |    "Enter Valid   Destination
             |    Days"          Data
             |         |              |
             |         |              ↓
             |         |         Calculate
             |         |         Costs
             |         |              |
             |         |              ↓
             |         |         ┌──────────────┐
             |         |         │ Travel Cost  │
             |         |         │ Stay Cost    │
             |         |         │ Food Cost    │
             |         |         │ Transport    │
             |         |         │ TOTAL COST   │
             |         |         └──────────────┘
             |         |              |
             |         |              ↓
             |         |         Display Cost
             |         |         Breakdown
             |         |              |
             |         |              ↓
             |         |         Generate
             |         |         Itinerary
             |         |              |
             |         |              ↓
             |         |         Display
             |         |         Tourist Places
             |         |              |
             |         |              ↓
             |         |         Display Best
             |         |         Season
             |         |              |
             |         |              ↓
             |         |         Show Results
             |         |         Section
             |         |              |
             └─────────┴──────────────┘
                      |
                      ↓
         Wait for Next Action
                      |
                      ↓
                    END
```

---

## 💰 Cost Calculation Flowchart

```
              START CALCULATION
                      |
                      ↓
         ┌─────────────────────────┐
         │ Get Destination Data    │
         │ from Database           │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ travelCost =            │
         │ data.travelCost         │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ stayCost =              │
         │ data.stayPerDay × days  │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ foodCost =              │
         │ data.foodPerDay × days  │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ transportCost =         │
         │ data.localTransport     │
         │      × days             │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ totalCost =             │
         │ travelCost + stayCost + │
         │ foodCost + transportCost│
         └─────────────────────────┘
                      |
                      ↓
              RETURN totalCost
                      |
                      ↓
                    END
```

---

## 📅 Itinerary Generation Flowchart

```
         START ITINERARY GENERATION
                      |
                      ↓
         Initialize day counter = 1
                      |
                      ↓
         ┌─────────────────────┐
         │ Is day ≤ numberOfDays?│
         └─────────────────────┘
                /        \
              NO          YES
              /            \
             ↓              ↓
         Display      ┌──────────────────┐
         Complete     │ Does predefined  │
         Itinerary    │ itinerary exist  │
             |        │ for this day?    │
             |        └──────────────────┘
             |             /        \
             |           YES         NO
             |           /            \
             |          ↓              ↓
             |    Get Predefined   Use Generic
             |    Activity from    Activity
             |    Database         Message
             |          |              |
             |          └──────┬───────┘
             |                 ↓
             |         Create Day Element
             |         with Activity
             |                 |
             |                 ↓
             |         Add to Display
             |                 |
             |                 ↓
             |         Increment day
             |                 |
             |                 └──────┐
             |                        |
             └────────────────────────┘
                      |
                      ↓
                    END
```

---

## ✅ Input Validation Flowchart

```
              START VALIDATION
                      |
                      ↓
         ┌─────────────────────┐
         │ Is destination      │
         │ empty or null?      │
         └─────────────────────┘
                /        \
              YES         NO
              /            \
             ↓              ↓
    Show Alert:      ┌─────────────┐
    "Please select   │ Is days a   │
    a destination"   │ number?     │
             |       └─────────────┘
             |            /      \
             |          NO        YES
             |          /          \
             |         ↓            ↓
             |    Show Alert:  ┌─────────┐
             |    "Enter       │ Is days │
             |    valid        │ < 1?    │
             |    number"      └─────────┘
             |         |          /    \
             |         |        YES    NO
             |         |        /      \
             |         |       ↓        ↓
             |         |  Show Alert  ┌─────────┐
             |         |  "Days must  │ Is days │
             |         |  be ≥ 1"     │ > 30?   │
             |         |       |      └─────────┘
             |         |       |        /    \
             |         |       |      YES    NO
             |         |       |      /      \
             |         |       |     ↓        ↓
             |         |       | Show Alert  VALID
             |         |       | "Days must  INPUT
             |         |       | be ≤ 30"      |
             |         |       |     |         |
             └─────────┴───────┴─────┴─────────┘
                      |
                      ↓
              RETURN to Main
                      |
                      ↓
                    END
```

---

## 🎨 Display Results Flowchart

```
           START DISPLAY RESULTS
                      |
                      ↓
         ┌─────────────────────────┐
         │ Call displayCost        │
         │ Breakdown()             │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ - Create cost items     │
         │ - Format currency       │
         │ - Show total            │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ Call displayItinerary() │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ - Loop through days     │
         │ - Create day cards      │
         │ - Add activities        │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ Call displayTourist     │
         │ Places()                │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ - Loop through places   │
         │ - Create place cards    │
         │ - Display in grid       │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ Call displayBestSeason()│
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ - Format season info    │
         │ - Highlight months      │
         │ - Display message       │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ Make results section    │
         │ visible                 │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ Scroll to results       │
         │ (smooth animation)      │
         └─────────────────────────┘
                      |
                      ↓
                    END
```

---

## 🗂️ Data Retrieval Flowchart

```
         START DATA RETRIEVAL
                      |
                      ↓
         ┌─────────────────────────┐
         │ Input: destination key  │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ Access destinationsDB   │
         │ object                  │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ Get data using key:     │
         │ destinationsDB[key]     │
         └─────────────────────────┘
                      |
                      ↓
         ┌─────────────────────────┐
         │ Extract:                │
         │ - name                  │
         │ - travelCost            │
         │ - stayPerDay            │
         │ - foodPerDay            │
         │ - localTransportPerDay  │
         │ - touristPlaces[]       │
         │ - bestSeason            │
         │ - itinerary{}           │
         └─────────────────────────┘
                      |
                      ↓
         RETURN destination data
                      |
                      ↓
                    END
```

---

## 🎯 Complete System Flowchart (Simplified)

```
┌─────────────────────────────────────────────────────────┐
│                      USER INTERFACE                      │
│  ┌────────────┐  ┌────────────┐  ┌──────────────────┐  │
│  │ Destination│  │   Days     │  │ Calculate Button │  │
│  │  Dropdown  │  │   Input    │  │                  │  │
│  └────────────┘  └────────────┘  └──────────────────┘  │
└─────────────────────────────────────────────────────────┘
                          |
                          ↓
┌─────────────────────────────────────────────────────────┐
│                   INPUT VALIDATION                       │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Check if destination selected                    │   │
│  │ Check if days is valid number (1-30)            │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
                          |
                          ↓
┌─────────────────────────────────────────────────────────┐
│                  DATA PROCESSING                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │ Retrieve destination data from database         │   │
│  │ Calculate: Travel + Stay + Food + Transport     │   │
│  │ Generate day-wise itinerary                     │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
                          |
                          ↓
┌─────────────────────────────────────────────────────────┐
│                   RESULTS DISPLAY                        │
│  ┌──────────────┐  ┌──────────────┐  ┌─────────────┐  │
│  │ Cost         │  │  Itinerary   │  │  Tourist    │  │
│  │ Breakdown    │  │  (Day-wise)  │  │  Places     │  │
│  └──────────────┘  └──────────────┘  └─────────────┘  │
│  ┌──────────────┐                                      │
│  │ Best Season  │                                      │
│  └──────────────┘                                      │
└─────────────────────────────────────────────────────────┘
```

---

## 📊 Flowchart Symbols Legend

| Symbol | Meaning |
|--------|---------|
| Rectangle | Process/Action |
| Diamond | Decision/Condition |
| Parallelogram | Input/Output |
| Oval | Start/End |
| Arrow | Flow Direction |
| Rectangle with double lines | Predefined Process/Function |

---

## 🎓 Flowchart Explanation for Viva

### Key Points to Explain:

1. **Sequential Flow**: The program follows a clear top-to-bottom flow
2. **Decision Points**: Input validation uses diamond shapes for conditions
3. **Loops**: Itinerary generation uses a loop to create multiple day entries
4. **Function Calls**: Separate flowcharts for each major function
5. **Data Flow**: Shows how data moves from input to output

### Questions You Might Be Asked:

**Q1: What happens if user doesn't select a destination?**
- A: The validation flowchart shows an alert is displayed and the process stops

**Q2: How is the total cost calculated?**
- A: The cost calculation flowchart shows: Total = Travel + (Stay × Days) + (Food × Days) + (Transport × Days)

**Q3: What if the number of days exceeds predefined itinerary?**
- A: The itinerary flowchart shows a generic message is used for days without predefined activities

**Q4: Where is the data stored?**
- A: In a JavaScript object called `destinationsDB` (shown in data retrieval flowchart)

**Q5: Is the process synchronous or asynchronous?**
- A: Synchronous - each step completes before the next begins (shown by sequential flow)

---

**Flowchart Complexity**: Beginner to Intermediate  
**Total Flowcharts**: 6 (Main + 5 Sub-processes)  
**Suitable For**: 2nd Semester Engineering Viva
